This is a more sophisticated version of our Delphi 2 sample.
Written by Robert Amlung
